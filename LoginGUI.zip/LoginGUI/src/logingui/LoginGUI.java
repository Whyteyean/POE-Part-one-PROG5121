/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package logingui;

/**
 *
 * @author RC_Student_Lab
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;

public class LoginGUI extends JFrame {
    private final Login loginSystem;
    private JTextField usernameField, cellNumberField;
    private JPasswordField passwordField, loginPasswordField;
    private JTextField loginUsernameField;
    private JTextArea outputArea;
    private JTabbedPane tabbedPane;
    
    // YEAN color scheme
    private final Color PRIMARY_COLOR = new Color(65, 105, 225);  // Royal Blue
    private final Color SECONDARY_COLOR = new Color(30, 144, 255); // Dodger Blue
    private final Color ACCENT_COLOR = new Color(255, 255, 255);   // White
    private final Color BACKGROUND_COLOR = new Color(248, 249, 250); // Light gray
    private final Color TEXT_COLOR = new Color(38, 38, 38); // Dark gray
    private final Color BORDER_COLOR = new Color(219, 219, 219);
    private final Color LIGHT_TEXT_COLOR = new Color(142, 142, 142);

    public LoginGUI() {
        loginSystem = new Login();
        initializeUI();
    }

    private void initializeUI() {
        setTitle("YEAN - Your Social Network");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 600); // Reduced height since we removed fields
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(BACKGROUND_COLOR);

        // Create header panel with YEAN branding
        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);
        
        tabbedPane = new JTabbedPane();
        tabbedPane.setBackground(BACKGROUND_COLOR);
        tabbedPane.setForeground(TEXT_COLOR);
        tabbedPane.setBorder(BorderFactory.createEmptyBorder());
        
        // Registration Panel
        JPanel registrationPanel = createRegistrationPanel();
        tabbedPane.addTab("Sign Up", null, registrationPanel, "Create a new YEAN account");
        
        // Login Panel
        JPanel loginPanel = createLoginPanel();
        tabbedPane.addTab("Log In", null, loginPanel, "Sign in to your YEAN account");
        
        // Output area (hidden by default, shows on messages)
        outputArea = new JTextArea(4, 50);
        outputArea.setEditable(false);
        outputArea.setLineWrap(true);
        outputArea.setWrapStyleWord(true);
        outputArea.setBackground(ACCENT_COLOR);
        outputArea.setForeground(TEXT_COLOR);
        outputArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        outputArea.setFont(new Font("Helvetica Neue", Font.PLAIN, 12));
        outputArea.setVisible(false); // Initially hidden
        
        JScrollPane scrollPane = new JScrollPane(outputArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setVisible(false);
        
        // Main layout
        add(tabbedPane, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);
    }

    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(ACCENT_COLOR);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR),
            BorderFactory.createEmptyBorder(15, 0, 15, 0)
        ));
        
        // YEAN logo with gradient effect
        JLabel logoLabel = new JLabel("YEAN", SwingConstants.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Create blue gradient
                GradientPaint gradient = new GradientPaint(
                    0, 0, PRIMARY_COLOR, 
                    getWidth(), getHeight(), SECONDARY_COLOR
                );
                g2.setPaint(gradient);
                g2.setFont(new Font("Helvetica Neue", Font.BOLD, 32));
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(getText())) / 2;
                int y = ((getHeight() - fm.getHeight()) / 2) + fm.getAscent();
                g2.drawString(getText(), x, y);
            }
        };
        
        logoLabel.setFont(new Font("Helvetica Neue", Font.BOLD, 32));
        logoLabel.setPreferredSize(new Dimension(200, 60));
        
        panel.add(logoLabel, BorderLayout.CENTER);
        
        return panel;
    }

    private JPanel createRegistrationPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(ACCENT_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;

        // Title
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel titleLabel = new JLabel("Create Your YEAN Account", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Helvetica Neue", Font.BOLD, 16));
        titleLabel.setForeground(PRIMARY_COLOR);
        panel.add(titleLabel, gbc);

        // Subtitle
        gbc.gridy = 1;
        JLabel subtitleLabel = new JLabel("Join our community with just a few details", SwingConstants.CENTER);
        subtitleLabel.setFont(new Font("Helvetica Neue", Font.PLAIN, 12));
        subtitleLabel.setForeground(LIGHT_TEXT_COLOR);
        panel.add(subtitleLabel, gbc);

        // Username
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        usernameField = createInstagramTextField("Username");
        panel.add(usernameField, gbc);
        
        // Username requirements
        gbc.gridy = 3;
        JLabel usernameReqLabel = new JLabel("Must contain underscore and be 5 characters or less", SwingConstants.CENTER);
        usernameReqLabel.setFont(new Font("Helvetica Neue", Font.ITALIC, 10));
        usernameReqLabel.setForeground(LIGHT_TEXT_COLOR);
        panel.add(usernameReqLabel, gbc);
        
        // Password
        gbc.gridy = 4;
        passwordField = createInstagramPasswordField("Password");
        panel.add(passwordField, gbc);
        
        // Password requirements
        gbc.gridy = 5;
        JLabel passwordReqLabel = new JLabel("Must be 8+ characters with capital, number, and special character", SwingConstants.CENTER);
        passwordReqLabel.setFont(new Font("Helvetica Neue", Font.ITALIC, 10));
        passwordReqLabel.setForeground(LIGHT_TEXT_COLOR);
        panel.add(passwordReqLabel, gbc);
        
        // Cell Number
        gbc.gridy = 6;
        cellNumberField = createInstagramTextField("Cell Number (+27XXXXXXXXX)");
        panel.add(cellNumberField, gbc);
        
        // Cell number requirements
        gbc.gridy = 7;
        JLabel cellReqLabel = new JLabel("South African format with international code", SwingConstants.CENTER);
        cellReqLabel.setFont(new Font("Helvetica Neue", Font.ITALIC, 10));
        cellReqLabel.setForeground(LIGHT_TEXT_COLOR);
        panel.add(cellReqLabel, gbc);
        
        // Terms text
        gbc.gridy = 8;
        JLabel termsLabel = new JLabel("<html><center>By signing up, you agree to our Terms, Privacy Policy and Cookies Policy.</center></html>", SwingConstants.CENTER);
        termsLabel.setFont(new Font("Helvetica Neue", Font.PLAIN, 11));
        termsLabel.setForeground(LIGHT_TEXT_COLOR);
        panel.add(termsLabel, gbc);

        // Register Button
        gbc.gridy = 9;
        JButton registerButton = createInstagramButton("Create Account", PRIMARY_COLOR);
        registerButton.addActionListener(new RegisterButtonListener());
        panel.add(registerButton, gbc);
        
        // Already have account link
        gbc.gridy = 10;
        JPanel loginRedirect = new JPanel(new FlowLayout(FlowLayout.CENTER));
        loginRedirect.setBackground(ACCENT_COLOR);
        JLabel haveAccount = new JLabel("Already have an account?");
        haveAccount.setForeground(TEXT_COLOR);
        haveAccount.setFont(new Font("Helvetica Neue", Font.PLAIN, 12));
        
        JButton loginLink = new JButton("Sign in");
        loginLink.setBorderPainted(false);
        loginLink.setContentAreaFilled(false);
        loginLink.setForeground(PRIMARY_COLOR);
        loginLink.setFont(new Font("Helvetica Neue", Font.BOLD, 12));
        loginLink.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginLink.addActionListener(e -> tabbedPane.setSelectedIndex(1));
        
        loginRedirect.add(haveAccount);
        loginRedirect.add(loginLink);
        panel.add(loginRedirect, gbc);

        return panel;
    }

    private JPanel createLoginPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(ACCENT_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(40, 50, 30, 50));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;

        // YEAN logo
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel logoLabel = new JLabel("YEAN", SwingConstants.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                GradientPaint gradient = new GradientPaint(
                    0, 0, PRIMARY_COLOR, 
                    getWidth(), getHeight(), SECONDARY_COLOR
                );
                g2.setPaint(gradient);
                g2.setFont(new Font("Helvetica Neue", Font.BOLD, 40));
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(getText())) / 2;
                int y = ((getHeight() - fm.getHeight()) / 2) + fm.getAscent();
                g2.drawString(getText(), x, y);
            }
        };
        logoLabel.setPreferredSize(new Dimension(200, 80));
        panel.add(logoLabel, gbc);

        // Welcome message
        gbc.gridy = 1;
        JLabel welcomeLabel = new JLabel("Welcome back to YEAN", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Helvetica Neue", Font.PLAIN, 14));
        welcomeLabel.setForeground(LIGHT_TEXT_COLOR);
        panel.add(welcomeLabel, gbc);

        // Username
        gbc.gridy = 2;
        loginUsernameField = createInstagramTextField("Username");
        panel.add(loginUsernameField, gbc);

        // Password
        gbc.gridy = 3;
        loginPasswordField = createInstagramPasswordField("Password");
        panel.add(loginPasswordField, gbc);

        // Login Button
        gbc.gridy = 4;
        JButton loginButton = createInstagramButton("Log In", PRIMARY_COLOR);
        loginButton.addActionListener(new LoginButtonListener());
        panel.add(loginButton, gbc);
        
        // Forgot password
        gbc.gridy = 5;
        JLabel forgotLabel = new JLabel("Forgot password?", SwingConstants.CENTER);
        forgotLabel.setForeground(LIGHT_TEXT_COLOR);
        forgotLabel.setFont(new Font("Helvetica Neue", Font.PLAIN, 11));
        forgotLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        panel.add(forgotLabel, gbc);
        
        // Sign up redirect
        gbc.gridy = 6;
        JPanel signupRedirect = new JPanel(new FlowLayout(FlowLayout.CENTER));
        signupRedirect.setBackground(ACCENT_COLOR);
        signupRedirect.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER_COLOR));
        signupRedirect.setPreferredSize(new Dimension(350, 60));
        
        JLabel noAccount = new JLabel("Don't have a YEAN account?");
        noAccount.setForeground(TEXT_COLOR);
        noAccount.setFont(new Font("Helvetica Neue", Font.PLAIN, 12));
        
        JButton signupLink = new JButton("Sign up");
        signupLink.setBorderPainted(false);
        signupLink.setContentAreaFilled(false);
        signupLink.setForeground(PRIMARY_COLOR);
        signupLink.setFont(new Font("Helvetica Neue", Font.BOLD, 12));
        signupLink.setCursor(new Cursor(Cursor.HAND_CURSOR));
        signupLink.addActionListener(e -> tabbedPane.setSelectedIndex(0));
        
        signupRedirect.add(noAccount);
        signupRedirect.add(signupLink);
        panel.add(signupRedirect, gbc);

        return panel;
    }
    
    private JTextField createInstagramTextField(String placeholder) {
        JTextField field = new JTextField(20);
        field.setText(placeholder);
        field.setForeground(LIGHT_TEXT_COLOR);
        field.setFont(new Font("Helvetica Neue", Font.PLAIN, 12));
        field.setBackground(ACCENT_COLOR);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        field.setPreferredSize(new Dimension(350, 40));
        
        field.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (field.getText().equals(placeholder)) {
                    field.setText("");
                    field.setForeground(TEXT_COLOR);
                }
            }
            @Override
            public void focusLost(java.awt.event.FocusEvent evt) {
                if (field.getText().isEmpty()) {
                    field.setForeground(LIGHT_TEXT_COLOR);
                    field.setText(placeholder);
                }
            }
        });
        
        return field;
    }
    
    private JPasswordField createInstagramPasswordField(String placeholder) {
        JPasswordField field = new JPasswordField(20);
        field.setEchoChar((char) 0);
        field.setText(placeholder);
        field.setForeground(LIGHT_TEXT_COLOR);
        field.setFont(new Font("Helvetica Neue", Font.PLAIN, 12));
        field.setBackground(ACCENT_COLOR);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        field.setPreferredSize(new Dimension(350, 40));
        
        field.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (String.valueOf(field.getPassword()).equals(placeholder)) {
                    field.setText("");
                    field.setEchoChar('•');
                    field.setForeground(TEXT_COLOR);
                }
            }
            @Override
            public void focusLost(java.awt.event.FocusEvent evt) {
                if (field.getPassword().length == 0) {
                    field.setEchoChar((char) 0);
                    field.setForeground(LIGHT_TEXT_COLOR);
                    field.setText(placeholder);
                }
            }
        });
        
        return field;
    }
    
    private JButton createInstagramButton(String text, Color color) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                if (getModel().isPressed()) {
                    g2.setColor(color.darker());
                } else if (getModel().isRollover()) {
                    g2.setColor(color.brighter());
                } else {
                    g2.setColor(color);
                }
                
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 8, 8));
                g2.dispose();
                
                super.paintComponent(g);
            }
        };
        
        button.setFont(new Font("Helvetica Neue", Font.BOLD, 14));
        button.setForeground(ACCENT_COLOR);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setOpaque(false);
        button.setPreferredSize(new Dimension(350, 40));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        return button;
    }
    
    private void showMessage(String message) {
        outputArea.setText(message);
        outputArea.setVisible(true);
        ((JScrollPane)outputArea.getParent().getParent()).setVisible(true);
        revalidate();
        repaint();
    }




    private class RegisterButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Get values from fields - only username, password, and cell number
            String username = usernameField.getText().equals("Username") ? "" : usernameField.getText();
            String password = String.valueOf(passwordField.getPassword());
            String cellNumber = cellNumberField.getText().equals("Cell Number (+27XXXXXXXXX)") ? "" : cellNumberField.getText();

            if (password.equals("Password")) password = "";

            // Set values in login system
            loginSystem.setUsername(username);
            loginSystem.setPassword(password);
            loginSystem.setCellNumber(cellNumber);

            // Validate and register
            String result = loginSystem.registerUser();
            showMessage("Registration Result: " + result);
            
            // Clear password field for security
            if (passwordField.getPassword().length > 0) {
                passwordField.setText("");
                passwordField.setEchoChar('•');
            }
        }
    }

    private class LoginButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String username = loginUsernameField.getText().equals("Username") ? "" : loginUsernameField.getText();
            String password = String.valueOf(loginPasswordField.getPassword());
            
            if (password.equals("Password")) password = "";
            
            String result = loginSystem.returnLoginStatus(username, password);
            showMessage("Login Attempt: " + result);
            
            // Clear password field for security
            if (loginPasswordField.getPassword().length > 0) {
                loginPasswordField.setText("");
                loginPasswordField.setEchoChar('•');
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | UnsupportedLookAndFeelException e) {
            }
            
            LoginGUI gui = new LoginGUI();
            gui.setVisible(true);
        });
    }
}
